Build of ReoGrid 0.8.5 - Core Feature Only 
