using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("The Grouper Test Harness")]
[assembly: AssemblyDescription("Tests the functionality of the Grouper control.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CodeVendor")]
[assembly: AssemblyProduct("Grouper")]
[assembly: AssemblyCopyright("Copyright � 2005 CodeVendor, All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
