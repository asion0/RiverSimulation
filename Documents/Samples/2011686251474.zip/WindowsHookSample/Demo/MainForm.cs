﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsHookSample;

namespace Demo
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            MouseHook.Enabled = true;
            MouseHook.GlobalMouseClick += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseClick);
            MouseHook.GlobalMouseDoubleClick += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseDoubleClick);
            MouseHook.GlobalMouseDown += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseDown);
            MouseHook.GlobalMouseUp += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseUp);
            MouseHook.GlobalMouseMove += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseMove);
            MouseHook.GlobalMouseWheel += new EventHandler<MouseHook.MouseEventArgs>(MouseHook_GlobalMouseWheel);

            KeyboardHook.Enabled = true;
            KeyboardHook.GlobalKeyDown += new EventHandler<KeyboardHook.KeyEventArgs>(KeyboardHook_GlobalKeyDown);
            KeyboardHook.GlobalKeyUp += new EventHandler<KeyboardHook.KeyEventArgs>(KeyboardHook_GlobalKeyUp);
        }

        void KeyboardHook_GlobalKeyUp(object sender, KeyboardHook.KeyEventArgs e)
        {
            listBox1.Items.Add("KeyDown: " + e.Keys.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void KeyboardHook_GlobalKeyDown(object sender, KeyboardHook.KeyEventArgs e)
        {
            listBox1.Items.Add("KeyDown: " + e.Keys.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseWheel(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add("MouseWheel: " + e.Delta);
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseDoubleClick(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add("MouseButtonDoubleClick: " + e.Button.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseMove(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add(String.Format("MouseMove X:{0:0000} Y:{1:0000}", e.X, e.Y));
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseUp(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add("MouseButtonUp: " + e.Button.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseDown(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add("MouseButtonDown: " + e.Button.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        void MouseHook_GlobalMouseClick(object sender, MouseHook.MouseEventArgs e)
        {
            listBox1.Items.Add("MouseButtonClick: " + e.Button.ToString());
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.dotblogs.com.tw/optimist9266");
        }
    }
}
